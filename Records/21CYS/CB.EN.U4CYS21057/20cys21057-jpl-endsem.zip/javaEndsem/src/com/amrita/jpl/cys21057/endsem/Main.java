package com.amrita.jpl.cys21057.endsem;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;

/**
 * This code contains inheritance, interfaces, UI
 *
 * @author Pushpanth
 */
public class Main {

    private String fileName;
    private int fileSize;

    Main(String fileName, int fileSize){
        this.fileName = fileName;
        this.fileSize = fileSize;
    }

    public String getFileName(){
        return fileName;
    }

    public void setFileName(String fileName){
        this.fileName = fileName;
    }

    public int  getFileSize(){
        return fileSize;
    }

    public void setFileSize(int fileSize){
        this.fileSize = fileSize;
    }

    public void displayFileDetails(String fileName,int fileSize){

        System.out.println("File name : " + fileName);
        System.out.println("File Size : " + fileSize);
    }


    public class Document extends Main {

        private String documentType;

        Document(String fileName, int fileSize) {
            super(fileName, fileSize);
        }

        public String getDocumentType(){
            return documentType;
        }

        public void setDocumentType(String documentType){
            this.documentType = documentType;
        }

    }

    public class Image extends Main {

        private int resolution;

        Image(String fileName, int fileSize) {
            super(fileName, fileSize);
        }

        public int getResolution(){
            return resolution;
        }

        public void setResolution(){
            this.resolution = resolution;
        }


    }


    class Video extends Main {

        private double duration;

        Video(String fileName, int fileSize) {
            super(fileName, fileSize);
        }

        public double getDuration(){
            return duration;
        }

        public void setDuration(double duration){
            this.duration = duration;
        }
    }

    interface FileManager {

        void addFile(Main file);
        void deleteFile(String fileName);
        void displayAllFiles();
    }

    public class FileManagerImp implements FileManager {

        private ArrayList<Main> files;

        public FileManagerImp() {
            files = new ArrayList<>();
        }

        public void addFile(Main file) {
            files.add(file);
        }

        public void deleteFile(String fileName) {
            for (int i = 0; i < files.size(); i++) {
                Main obj = files.get(i);
                if (obj.getFileName().equals(fileName)) {
                    files.remove(i);
                    break;
                }
            }
        }

        public void displayAllFiles() {

            for(int i=0;i<=files.size();i++){
                Main obj = files.get(i);
                System.out.println(obj.getFileName());
            }
        }


    }


    public static class FMSui extends JFrame {
        private JTextField filePathField;
        private JButton browseButton;
        private JButton deleteButton;
        private JTable fileTable;
        private DefaultTableModel tableModel;

        public FMSui() {
            setTitle("File Management System");
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setSize(500, 400);
            setLayout(new BorderLayout());


            JPanel topPanel = new JPanel();
            topPanel.setLayout(new FlowLayout());
            filePathField = new JTextField(20);
            browseButton = new JButton("Browse");
            browseButton.addActionListener(new BrowseButtonListener());
            topPanel.add(filePathField);
            topPanel.add(browseButton);
            add(topPanel, BorderLayout.NORTH);


            tableModel = new DefaultTableModel();
            tableModel.addColumn("File Name");
            tableModel.addColumn("File Size");
            tableModel.addColumn("File Type");
            fileTable = new JTable(tableModel);
            JScrollPane scrollPane = new JScrollPane(fileTable);
            add(scrollPane, BorderLayout.CENTER);


            JPanel bottomPanel = new JPanel();
            bottomPanel.setLayout(new FlowLayout());
            deleteButton = new JButton("Delete");
            deleteButton.addActionListener(new DeleteButtonListener());
            bottomPanel.add(deleteButton);
            add(bottomPanel, BorderLayout.SOUTH);
        }

        private class BrowseButtonListener implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int option = fileChooser.showOpenDialog(FMSui.this);
                if (option == JFileChooser.APPROVE_OPTION) {
                    java.io.File selectedFile = fileChooser.getSelectedFile();
                    String filePath = selectedFile.getPath();
                    filePathField.setText(filePath);
                }
            }
        }

        private class DeleteButtonListener implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = fileTable.getSelectedRow();
                if (selectedRow != -1) {
                    tableModel.removeRow(selectedRow);
                } else {
                    JOptionPane.showMessageDialog(FMSui.this, "Please select a file to delete.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }


            public static void main(String[] args) {


                FMSui obj = new FMSui();
                obj.setVisible(true);
            }
        }